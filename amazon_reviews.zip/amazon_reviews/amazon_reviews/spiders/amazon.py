from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.selector import Selector
from scrapy.linkextractors import LinkExtractor


class AmazonreviewsSpider(CrawlSpider):

    name = "amazon_reviews"

    start_urls = ["https://www.amazon.com/DEGOL-Skipping-Tangle-Free-Bearings-Endurance/product-reviews/B07P2F2YHT/ref=cm_cr_dp_d_show_all_btm?ie=UTF8&reviewerType=all_reviews"]


    def parse(self,response):
        
        for data in response.css(".a-section.review.aok-relative"):
        
            yield{
                "name" : data.css(".a-profile-name::text").extract_first(),
                "rating" : data.css(".a-icon-alt::text").extract_first(),
                "date" : data.css(".a-size-base.a-color-secondary.review-date::text").extract_first(),
                "review" : data.css(".a-size-base.review-text.review-text-content span::text").extract_first()
            }
        
        next_page = response.css(".a-last a::attr(href)").extract_first()
        
        if next_page:
            yield response.follow(next_page,callback=self.parse)
